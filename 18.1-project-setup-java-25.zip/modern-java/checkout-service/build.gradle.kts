plugins {
    id("java")
}

group = "com.modernjava"
version = ""


repositories {
    mavenCentral()
}

