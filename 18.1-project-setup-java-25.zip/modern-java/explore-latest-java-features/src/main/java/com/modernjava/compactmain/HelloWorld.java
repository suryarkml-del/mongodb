package com.modernjava.compactmain;

public class HelloWorld {
    String name = "Dilip";

    public static void main() {
        System.out.println("Hello, World! ");
        IO.println("Hello, World! ");
    }
}
