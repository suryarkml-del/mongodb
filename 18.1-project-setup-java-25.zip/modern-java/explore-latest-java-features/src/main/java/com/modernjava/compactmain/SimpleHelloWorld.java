String name = "Dilip";
String course = "Modern Java"; // introduced variable

void main() {
    System.out.println("Hello, World! ");
    IO.println("Hello, World! ");
    IO.println("Hello, World! " + name);
    IO.println("Course: " + course); // print course variable
}