package com.modernjava.sealed;

public final class FlyingCar extends Car {
}
