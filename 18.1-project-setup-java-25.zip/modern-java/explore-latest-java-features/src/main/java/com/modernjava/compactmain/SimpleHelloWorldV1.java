String name = "Dilip";
String course = "Modern Java - Compact Main";
int javaVersion = 25;

void main() {
    IO.println("Welcome to Java " + javaVersion + "!");
    IO.println("Hello from " + name);
    IO.println("Course: " + course);
    IO.println();
}
