package com.modernjava.patternmatching.recordmatch;

public record Dog(String name,
                  String color) implements Animal {
}
