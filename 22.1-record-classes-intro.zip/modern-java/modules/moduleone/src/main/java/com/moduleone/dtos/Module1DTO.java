package com.moduleone.dtos;

public record Module1DTO(String name) {
}
