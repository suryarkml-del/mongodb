package com.modulefour.service;

public class ModuleFourService {

    public String retrieve(){
        return "UnNamed";
    }
}
