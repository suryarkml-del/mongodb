module moduleone {
    requires java.net.http;

    exports com.moduleone.dtos;
    exports com.moduleone.service;

}