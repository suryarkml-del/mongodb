package com.moduleone.secret;

public class Secret {

    public String secret(){
        return "$ecrEt";
    }
}
