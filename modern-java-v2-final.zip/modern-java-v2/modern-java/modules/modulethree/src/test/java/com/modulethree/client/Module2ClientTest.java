package com.modulethree.client;


class Module2ClientTest {

    void retrieveData() {

    }
}