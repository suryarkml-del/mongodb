package com.modernjava.patternmatching.recordMatch;

public record Dog(String name,
                  String color) implements Animal {
}
