package com.modernjava.patternmatching.recordMatch;

public sealed interface Animal permits Cat, Dog {
}
