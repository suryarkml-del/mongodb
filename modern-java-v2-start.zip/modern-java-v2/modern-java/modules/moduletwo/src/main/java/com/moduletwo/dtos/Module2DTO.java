package com.moduletwo.dtos;

public record Module2DTO(String name) {
}
