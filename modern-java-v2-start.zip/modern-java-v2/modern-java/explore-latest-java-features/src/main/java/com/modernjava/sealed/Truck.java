package com.modernjava.sealed;

public class Truck extends Vehicle{
}
