package com.modernjava.sealed;

public class Vehicle {
}

