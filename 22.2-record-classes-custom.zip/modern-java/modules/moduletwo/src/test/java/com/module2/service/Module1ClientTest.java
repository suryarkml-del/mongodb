package com.module2.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class Module1ClientTest {

    @Test
    void retrieveData() {
    }
}