package com.modernjava.collectionfactories;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static java.util.Map.entry;

public class ExploreCollection {

    public static void main(String[] args) {
    }
}
